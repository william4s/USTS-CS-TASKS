w=float(input())
for i in range(0,10):
    w+=0.5
print("moon's weight is {}".format(w*0.165))
print("earth's weight is {}".format(w))