a=float(input())
if (a>=90) :
    print("优")
elif (80<=a<90) :
    print("良")
elif (70<=a<80) :
    print("中") 
elif (60<=a<70):
    print("及格")
else:
    print("不及格")