sum=int(0)
i=int(1)
while(i<=100):
    sum+=i
    i+=1
print(sum)